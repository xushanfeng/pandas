def print_template():
    # 打印数据模板
    return {
        'title': '南阳桐柏宏鑫钢构 岩棉复合板 单瓦 楼承板 C Z 型钢',
        # 'sub_title': '黄石山力 天津新宇彩卷南阳总代理 销售出货单',
        'sub_title': '',
        'connect': '南阳兴达钢材市场 电话：186 2562 5566',
        'out_date': '',
        'out_status': '已出货',
        'order_no': '',
        'guest_name': '',
        'check': '',
        'guest_phone': '',
        'pay': '',
        'amount_receivable': '',
        'discount_amount': '',
        'details': {

        }
    }


